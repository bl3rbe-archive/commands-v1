# welcomer
an Open source welcomer for discord (don’t remove credits.)

### Things not to do:
- dont be dumb
- dont remove credits
- dont copy paste or youll never learn
### Things u should do:
- star this repo
- give credits
- fork this repo
- join [Devs Hub](https://discord.gg/avbmZBrDsk) and [Dark Codes](https://discord.gg/devs)
<a href="https://discord.gg/avbmZBrDsk"><img src="https://media.discordapp.net/attachments/802570609430364170/812886938683310110/image0.png"></a> <a href="https://discord.gg/devs"><img src="https://media.discordapp.net/attachments/806537250459877438/812887554810576947/image0.png"></a>

###### If you have any errors, problems or want me to make you a custom bot (paid) dm me on discord (LΣGΣПD#0001)
`Note: i dont accept friend requests on discord (i have 124 friend requests thats why) so you will have to join devs hub or dark codes to dm me.`

#### Starting the bot
- `npm install`
- `node index.js`
