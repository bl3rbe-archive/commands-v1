# emote manager Bot
## This bot was made by legend-js & ant, do not remove credits or you will have copyright issues.
### Make sure to join The servers below:
- [Dark Studios (dark codes)](https://discord.gg/devs)
- [Developers Hub](https://discord.gg/avbmZBrDsk)
#### Star the repo and fork it, Ty
###### Things not to do:
- Dont be dumb
- Dont remove credits
- Dont say u created it when u didnt
- dont copy paste or u will never learn
##### Things to do:
- star this repo
- fork this repo
- follow me
- make videos on my projects
- join devs Hub
