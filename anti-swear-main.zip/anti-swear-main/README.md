# anti-swear
## things not to do:
- dont remove credits.
- dont copy paste or youll never learn.
## things you should do
- star this repo
- dont be dumb
